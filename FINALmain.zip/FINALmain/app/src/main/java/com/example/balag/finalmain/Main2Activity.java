package com.example.balag.finalmain;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.balag.finalmain.R;


public class Main2Activity extends AppCompatActivity {
    private Button signup;
    private ImageButton signin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        signin = (ImageButton) findViewById(R.id.signin);
        signin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity();
            }
        });
        signup = (Button) findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openUpsign();
            }
        });
    }
    public void openMainActivity(){
        Intent intent;
        intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        //setContentView(R.layout.activity_main2);
    }
    public void openUpsign() {
        Intent intent;
        intent = new Intent(this, Up_Sign.class);
        startActivity(intent);
        //setContentView(R.layout.activity_main2);
    }
}
